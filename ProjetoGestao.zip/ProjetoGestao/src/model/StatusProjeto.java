package model;

/**
 * Status possíveis para um projeto.
 */
public enum StatusProjeto {
    PLANEJADO,
    EM_ANDAMENTO,
    CONCLUIDO,
    CANCELADO
}

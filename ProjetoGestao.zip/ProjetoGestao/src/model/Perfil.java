package model;

/**
 * Perfil de usuário no sistema.
 */
public enum Perfil {
    ADMINISTRADOR,
    GERENTE,
    COLABORADOR
}

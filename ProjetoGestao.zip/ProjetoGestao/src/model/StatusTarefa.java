package model;

/**
 * Status possíveis para uma tarefa.
 */
public enum StatusTarefa {
    PENDENTE,
    EM_ANDAMENTO,
    CONCLUIDA
}
